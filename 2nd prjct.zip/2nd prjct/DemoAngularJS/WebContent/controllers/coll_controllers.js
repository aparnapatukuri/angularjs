
app.controller("myCtrl",function($scope)
		{
		
	$scope.user={
			fName:"Aparna",
		  lName:"Patukuri"
			
			
	}
			}
)


