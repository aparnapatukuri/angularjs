package com.niit.collaboration.model;

public class UserDetails {

}
