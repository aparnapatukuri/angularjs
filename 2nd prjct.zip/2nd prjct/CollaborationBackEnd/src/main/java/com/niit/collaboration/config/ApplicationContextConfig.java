package com.niit.collaboration.config;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration 
@ComponentScan("com.niit.collaboration")
@EnableTransactionManagement

public class ApplicationContextConfig {

	 @Bean(name = "dataSource")
	    public DataSource getDataSource() {
	    	BasicDataSource dataSource = new BasicDataSource();
	    	dataSource.setDriverClassName("oracle.jdbc.drive.OracleDrive");
	    	dataSource.setUrl("jdbc:oracle:thin:@amrood:1522:orcl");
	    	dataSource.setUsername("hr");
	    	dataSource.setPassword("hr");
	    	
	    	return dataSource;
	    }
	    
	    
	
}
